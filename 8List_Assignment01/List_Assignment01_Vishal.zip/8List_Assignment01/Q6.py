# Q6. Python Program to Find the Union of two Lists

list1 = [1,2,3,56,78,9,67,'hi']
list2 = ['how',67,'are',9,'you!!']
listun = list1 + list2
print("Union of lists: ",listun)


'''list1 = [1,2,3,56,78,9,67,'hi']
list2 = ['how',67,'are',9,'you!!']
for i in list2:
    list1.append(i)
print("Union of lists: ",list1)
'''
'''
list1 = [1,2,3,56,78,9,67,'hi']
list2 = ['how',67,'are',9,'you!!']
list1.extend(list2)
print("Union of lists: ",list1)
'''
