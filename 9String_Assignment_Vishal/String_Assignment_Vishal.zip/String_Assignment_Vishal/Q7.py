# 7. Python Program to Calculate the Length of a String Without Using a Library Function
sample = 'Python Program to Calculate the Length of a String Without Using a Library Function'
count = 0
for i in sample:
    count += 1
print("Given string: ", sample)
print("String Length: ", count)
