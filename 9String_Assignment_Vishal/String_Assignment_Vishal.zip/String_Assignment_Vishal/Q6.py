# 6. Python Program to Take in a String and Replace Every Blank Space with Hyphen.
sample = 'a cat eats mice'
sample = sample.replace(' ', '/')
print("String with /: ", sample)
