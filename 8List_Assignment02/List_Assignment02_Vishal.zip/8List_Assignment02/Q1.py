# 1.  Write a program to find sum of all elements of list 
data = [11,34,56,89,45,67]
sum = 0
for i in range(0,len(data)):
    sum += data[i]
print("Sum of the list elements: ",sum)

