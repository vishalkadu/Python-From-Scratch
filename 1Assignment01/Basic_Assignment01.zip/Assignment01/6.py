#Convert temp from Celsius to Fahrenheit. 
C = int(input("Enter temprature in celcius: "))
F = (C * (9/5)) + 32
print("Temprature in fahrenheit: ",F)