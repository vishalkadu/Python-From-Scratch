#  Write a program to calculate area of rectangle based on length and breadth.
Length = float(input("Enter the length: "))
Breadth = float(input("Enter the breadth: "))
Area = Length *  Breadth
print("Area of rectangle is",Area,"Sq.m")
