#WAP to calculate area of triangle and rectangle 
print("Area of tringle")
base = float(input("Input tringle's base: "))
height = float(input("Input tringle's height: "))
print("Area of tringle is",0.5 * base * height,"Sq.Units")
print("\nArea of rectangle")
length = float(input("Input rectangle's length: "))
breadth = float(input("Input rectangle's breadth: "))
print("Area of rectangle is",length * breadth,"Sq.Units")