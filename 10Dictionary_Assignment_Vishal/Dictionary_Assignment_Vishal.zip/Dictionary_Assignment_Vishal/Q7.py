# Q7. Python Program to Remove the Given Key from a Dictionary.
dic = {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}
dic.pop(int(input("Enter key to remove: ")))
print("Dictionary after removing key: ", dic)
